function f = benchmark_func(x,func_num)
global initial_flag
persistent fhd f_bias

if initial_flag==0
    if func_num==1 fhd=str2func('ellipsoid_func');
    elseif func_num==2 fhd=str2func('rosenbrock_func');
    elseif func_num==3 fhd=str2func('rastrigin_func');  
    elseif func_num==4 fhd=str2func('ackley_func');
    elseif func_num==5 fhd=str2func('griewank_func');
    elseif func_num==6 fhd=str2func('rastrigin_rot_func');  
    elseif func_num==7 fhd=str2func('hybrid_rot_func');
    elseif func_num==8 fhd=str2func('hybrid_rot_func_narrow');
    end
    
%     load('./datafiles/fbias_data');
end

f=feval(fhd,x);


%1. Ellipsoid Function
function fit = ellipsoid_func(x)    
d=size(x,2);
fi=1:d;
fit=sum(fi.*x.^2,2);

%2. Rosenbrock Function
function fit = rosenbrock_func(x)
D=size(x,2);
fit = sum(100.*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);

%3. Rastrigin Function
function fit=rastrigin_func(x)
[ps,D]=size(x);
fit=sum(x.^2-10.*cos(2.*pi.*x)+10,2);  


%4.  Ackley Function
function fit = ackley_func(x)
D = size(x,2);
fit = sum(x.^2,2);
fit = 20-20.*exp(-0.2.*sqrt(fit./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);

%5.  Griewank Function
function fit = griewank_func(x)
D = size(x, 2);
sumcomp = 0;
prodcomp = 1;
for i = 1:D
    sumcomp = sumcomp + (x(:, i) .^ 2);
    prodcomp = prodcomp .* (cos(x(:, i) / sqrt(i)));
end  
fit = (sumcomp / 4000) - prodcomp + 1;



%6.  Shifted Rotated Rastrigin
function f=rastrigin_rot_func(x)
global initial_flag
persistent o M
[ps,D]=size(x);
if initial_flag==0
    load ('./datafiles/rastrigin_func_data');
    if length(o)>=D
         o=o(1:D);
    else
         o=-5+10*rand(1,D);
    end
    c=2;
    if D==2,load ('./datafiles/rastrigin_M_D2'),
    elseif D==10,load ('./datafiles/rastrigin_M_D10'),
    elseif D==30,load ('./datafiles/rastrigin_M_D30'),
    elseif D==50,load ('./datafiles/rastrigin_M_D50'),
    else 
        M=rot_matrix(D,c);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
x=x*M;
f=sum(x.^2-10.*cos(2.*pi.*x)+10,2)-330;

% %7.  Rotated Hybrid Composition Function 1	
% function fit=hybrid_rot_func1(x)
% global initial_flag
% persistent  fun_num func o sigma lamda bias M
% if initial_flag==0
%     [ps,D]=size(x);
%     initial_flag=1;
%     fun_num=10;
%     load ('./datafiles/hybrid_func1_data') % saved the predefined optima
%     if length(o(1,:))>=D
%          o=o(:,1:D);
%     else
%          o=-5+10*rand(fun_num,D);
%     end
%     func.f1=str2func('frastrigin');
%     func.f2=str2func('frastrigin');
%     func.f3=str2func('fweierstrass');
%     func.f4=str2func('fweierstrass');
%     func.f5=str2func('fgriewank');
%     func.f6=str2func('fgriewank');
%     func.f7=str2func('fackley');
%     func.f8=str2func('fackley');
%     func.f9=str2func('fsphere');
%     func.f10=str2func('fsphere');
%     bias=((1:fun_num)-1).*100;
%     sigma=ones(1,fun_num); 
%     lamda=[1; 1; 10; 10; 5/60; 5/60; 5/32; 5/32; 5/100; 5/100];
%     lamda=repmat(lamda,1,D);
%     c=[2,2,2,2,2,2,2,2,2,2,2];
%     if D==2,load ('./datafiles/hybrid_func1_M_D2'),
%     elseif D==10,load ('./datafiles/hybrid_func1_M_D10'),
%     elseif D==30,load ('./datafiles/hybrid_func1_M_D30'),
%     elseif D==50,load ('./datafiles/hybrid_func1_M_D50'),
%     else 
%         for i=1:fun_num
%             eval(['M.M' int2str(i) '=rot_matrix(D,c(i));']);
%         end
%     end
% end
% fit=hybrid_composition_func(x,fun_num,func,o,sigma,lamda,bias,M)+120;

%7 Rotated hybrid composition function
function fit=hybrid_rot_func(x)
global initial_flag
persistent  fun_num func o sigma lamda bias M
if initial_flag==0
    D=size(x,2);
    initial_flag=1;
    fun_num=10;
    load ('./datafiles/hybrid_func2_data') % saved the predefined optima
    if length(o(1,:))>=D
         o=o(:,1:D);
    else
         o=-5+10*rand(fun_num,D);
    end
    o(10,:)=0;
    func.f1=str2func('fackley');
    func.f2=str2func('fackley');
    func.f3=str2func('frastrigin');
    func.f4=str2func('frastrigin');
    func.f5=str2func('fsphere');
    func.f6=str2func('fsphere');
    func.f7=str2func('fweierstrass');
    func.f8=str2func('fweierstrass');
    func.f9=str2func('fgriewank');
    func.f10=str2func('fgriewank');
    bias=((1:fun_num)-1).*100;
    sigma=[1 2 1.5 1.5 1 1 1.5 1.5 2 2];
    lamda=[2*5/32; 5/32; 2*1; 1; 2*5/100; 5/100; 2*10; 10; 2*5/60; 5/60];
    lamda=repmat(lamda,1,D);
    c=[2 3 2 3 2 3 20 30 200 300];
    if D==2,load ('./datafiles/hybrid_func2_M_D2'),
    elseif D==10,load ('./datafiles/hybrid_func2_M_D10'),
    elseif D==30,load ('./datafiles/hybrid_func2_M_D30'),
    elseif D==50,load ('./datafiles/hybrid_func2_M_D50'),
    else 
        for i=1:fun_num
            eval(['M.M' int2str(i) '=rot_matrix(D,c(i));']);
        end
    end
end
fit=hybrid_composition_func(x,fun_num,func,o,sigma,lamda,bias,M)+10;


%8  Rotated hybrid composition function with a narrow basin for the global optimum
function fit=hybrid_rot_func_narrow(x)
global initial_flag
persistent  fun_num func o sigma lamda bias M
if initial_flag==0
    D=size(x,2);
    initial_flag=1;
    fun_num=10;
    load ('./datafiles/hybrid_func2_data')% saved the predefined optima
    if length(o(1,:))>=D
         o=o(:,1:D);
    else
         o=-5+10*rand(fun_num,D);
    end
    o(10,:)=0;
    func.f1=str2func('fackley');
    func.f2=str2func('fackley');
    func.f3=str2func('frastrigin');
    func.f4=str2func('frastrigin');
    func.f5=str2func('fsphere');
    func.f6=str2func('fsphere');
    func.f7=str2func('fweierstrass');
    func.f8=str2func('fweierstrass');
    func.f9=str2func('fgriewank');
    func.f10=str2func('fgriewank');
    bias=((1:fun_num)-1).*100;
    sigma=[0.1 2 1.5 1.5 1 1 1.5 1.5 2 2];
    lamda=[0.1*5/32; 5/32; 2*1; 1; 2*5/100; 5/100; 2*10; 10; 2*5/60; 5/60];
    lamda=repmat(lamda,1,D);
    c=[2 3 2 3 2 3 20 30 200 300];
    if D==2,load ('./datafiles/hybrid_func2_M_D2'),
    elseif D==10,load ('./datafiles/hybrid_func2_M_D10'),
    elseif D==30,load ('./datafiles/hybrid_func2_M_D30'),
    elseif D==50,load ('./datafiles/hybrid_func2_M_D50'),
    else 
        for i=1:fun_num
            eval(['M.M' int2str(i) '=rot_matrix(D,c(i));']);
        end
    end
end
fit=hybrid_composition_func(x,fun_num,func,o,sigma,lamda,bias,M)+10;


%----------------------------------
function fit=hybrid_composition_func(x,fun_num,func,o,sigma,lamda,bias,M)
[ps,D]=size(x);
for i=1:fun_num
    oo=repmat(o(i,:),ps,1);
    weight(:,i)=exp(-sum((x-oo).^2,2)./2./(D*sigma(i)^2));
end

[tmp,tmpid]=sort(weight,2);
for i=1:ps
    weight(i,:)=(weight(i,:)==tmp(i,fun_num)).*weight(i,:)+(weight(i,:)~=tmp(i,fun_num)).*(weight(i,:).*(1-tmp(i,fun_num).^10));
end
weight=weight./repmat(sum(weight,2),1,fun_num);

fit=0;
for i=1:fun_num
    oo=repmat(o(i,:),ps,1);
    eval(['f=feval(func.f' int2str(i) ',((x-oo)./repmat(lamda(i,:),ps,1))*M.M' int2str(i) ');']);
    x1=5*ones(1,D);
    eval(['f1=feval(func.f' int2str(i) ',(x1./lamda(i,:))*M.M' int2str(i) ');']);
    fit1=2000.*f./f1;
    fit=fit+weight(:,i).*(fit1+bias(i));
end


%-------------------------------------------------
%basic functions

function f=fsphere(x)
%Please notice there is no use to rotate a sphere function, with rotation
%here just for a similar structure as other functions and easy programming
[ps,D]=size(x);
f=sum(x.^2,2);
%--------------------------------
function f=fgriewank(x)
[ps,D]=size(x);
f=1;
for i=1:D
    f=f.*cos(x(:,i)./sqrt(i));
end
f=sum(x.^2,2)./4000-f+1;
%--------------------------------
function f=fackley(x)
[ps,D]=size(x);
f=sum(x.^2,2);
f=20-20.*exp(-0.2.*sqrt(f./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);
%--------------------------------
function f=frastrigin(x)
[ps,D]=size(x);
f=sum(x.^2-10.*cos(2.*pi.*x)+10,2);
%--------------------------------
%--------------------------------
function [f]=fweierstrass(x)
[ps,D]=size(x);
x=x+0.5;
a = 0.5;
b = 3;
kmax = 20;
c1(1:kmax+1) = a.^(0:kmax);
c2(1:kmax+1) = 2*pi*b.^(0:kmax);
f=0;
c=-w(0.5,c1,c2);
for i=1:D
f=f+w(x(:,i)',c1,c2);
end
f=f+c*D;
function y = w(x,c1,c2)
y = zeros(length(x),1);
for k = 1:length(x)
	y(k) = sum(c1 .* cos(c2.*x(:,k)));
end
%--------------------------------

function M=rot_matrix(D,c)
A=normrnd(0,1,D,D);
P=cGram_Schmidt(A);
A=normrnd(0,1,D,D);
Q=cGram_Schmidt(A);
u=rand(1,D);
D=c.^((u-min(u))./(max(u)-min(u)));
D=diag(D);
M=P*D*Q;

 function [q,r] = cGram_Schmidt (A)
% computes the QR factorization of $A$ via
% classical Gram Schmid 
% 
 [n,m] = size(A); 
 q = A;    
 for j=1:m
     for i=1:j-1 
         r(i,j) = q(:,j)'*q(:,i);
     end
     for i=1:j-1   
       q(:,j) = q(:,j) -  r(i,j)*q(:,i);
     end
     t =  norm(q(:,j),2 ) ;
     q(:,j) = q(:,j) / t ;
     r(j,j) = t  ;
 end 

