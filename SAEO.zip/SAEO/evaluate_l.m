function [val,fe,pop,popSample,valSample] = evaluate_l(fname, func_num, pop, pop_temp, val, fe, NP,popSample,valSample)


val_temp = feval(fname, pop_temp, func_num);
fe = fe + NP;
popSample = [popSample;pop_temp];
valSample = [valSample;val_temp];

index = find(val_temp < val);
pop(index,:) = pop_temp(index,:);
val(index,:) = val_temp(index,:);
end