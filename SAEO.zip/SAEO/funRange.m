function [Lbound, Ubound] = funRange(func_num,D, NP)
 
    if(ismember(func_num, [1, 3]))
        XRmin = -5.12*ones(NP,D); 
        XRmax = 5.12*ones(NP,D); 
        Lbound = XRmin;
        Ubound = XRmax;
    end
    if(ismember(func_num, 2))
        XRmin = -2.048*ones(NP,D); 
        XRmax = 2.048*ones(NP,D); 
        Lbound = XRmin;
        Ubound = XRmax;
    end
    if(ismember(func_num, 4))
        XRmin = -32.768*ones(NP,D); 
        XRmax = 32.768*ones(NP,D); 
        Lbound = XRmin;
        Ubound = XRmax;
    end
    if(ismember(func_num, 5))
        XRmin = -600*ones(NP,D); 
        XRmax = 600*ones(NP,D); 
        Lbound = XRmin;
        Ubound = XRmax;
    end
    if(ismember(func_num, [6, 7, 8]))
        XRmin = -5*ones(NP,D); 
        XRmax = 5*ones(NP,D); 
        Lbound = XRmin;
        Ubound = XRmax;
    end
end