function [pop_temp] = generate_l(D, NP, pop, val, fe, Max_FEs)

    pop_temp=[];
    for l = 1: NP
		
		randomRowNumber1 = floor(rand() * NP);

        
		if(randomRowNumber1 == 0) 
            randomRowNumber1 = randomRowNumber1 + 1; 
        end


        if( val(l,:) < val(randomRowNumber1,:) )
            pop_t = pop(l,:) + rand(1,D).*(pop(l,:) - pop(randomRowNumber1,:));
        else
			pop_t = pop(l,:) + rand(1,D).* (pop(randomRowNumber1,:) - pop(l,:));
        end
        [pop_temp] = [pop_temp;pop_t];
        
    end