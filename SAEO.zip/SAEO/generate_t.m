function [pop,val,fe,popSample,valSample] = generate_t(fname, func_num, D, NP, pop, Lbound, Ubound, bestmem,val,fe,popSample,valSample)


Tg = bestmem;
Mg = sum(pop)./NP;

%%%%%%%%%%%%%%%%%%%%%%%%
rand2 = (rand(NP,D) > 0.5) + ones(NP,D);

diffMean = rand(NP,D).*(repmat(Tg,NP,1)-rand2.*pop);

pop_temp = pop + diffMean;
pop_temp = repair(pop_temp, Lbound,Ubound);
val_temp = feval(fname, pop_temp, func_num);
popSample = [popSample;pop_temp];
valSample = [valSample;val_temp];
fe = fe + NP;

index = find(val_temp < val);
pop(index,:) = pop_temp(index,:);
val(index,:) = val_temp(index,:);

end